export default function ModalLayout({ children }) {
  return <>{children}</>;
}